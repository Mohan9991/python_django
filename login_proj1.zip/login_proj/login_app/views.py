from django.shortcuts import render,redirect
from django.http import HttpResponse
from login_app.forms import UserForm
from login_app.models import User
# Create your views here.
def log(request):
    if request.method=='POST':
        form=UserForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('suc.html')
    else:
        form=UserForm
        return render(request,'log.html',{'dts':form})
def success(request):
    return render(request,'suc.html')


    