from django.db import models

# Create your models here.
class User(models.Model):
    fname=models.CharField(max_length=50)
    lname=models.CharField(max_length=50)
    dob=models.CharField(max_length=50)
    ph=models.IntegerField()
    addr=models.CharField(max_length=50)
    class Meta:
        db_table='userdetails'